import axios from 'axios';
import { AuthResponse } from '../types';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';

class AuthService {
  private token: string | null = localStorage.getItem('token');
  private username: string | null = localStorage.getItem('username');

  constructor() {
    // Set up axios defaults
    if (this.token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${this.token}`;
    }
  }

  async login(username: string, password: string): Promise<AuthResponse> {
    try {
      const response = await axios.post<AuthResponse>(`${API_BASE_URL}/auth/login`, {
        username,
        password
      });

      const { token, username: returnedUsername } = response.data;
      
      // Store in localStorage
      localStorage.setItem('token', token);
      localStorage.setItem('username', returnedUsername);
      
      // Set axios header
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      
      this.token = token;
      this.username = returnedUsername;

      return response.data;
    } catch (error) {
      console.error('Login error:', error);
      throw new Error('Login failed');
    }
  }

  async register(username: string, password: string): Promise<void> {
    try {
      await axios.post(`${API_BASE_URL}/auth/register`, {
        username,
        password
      });
    } catch (error) {
      console.error('Registration error:', error);
      throw new Error('Registration failed');
    }
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    delete axios.defaults.headers.common['Authorization'];
    this.token = null;
    this.username = null;
  }

  getToken(): string | null {
    return this.token;
  }

  getUsername(): string | null {
    return this.username;
  }

  isLoggedIn(): boolean {
    return !!this.token;
  }
}

export const authService = new AuthService();
