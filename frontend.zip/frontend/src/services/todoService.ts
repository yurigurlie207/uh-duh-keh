import axios from 'axios';
import { Todo, UserPreferences, User } from '../types';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';

class TodoService {
  async getTodos(): Promise<Todo[]> {
    try {
      const response = await axios.get<Todo[]>(`${API_BASE_URL}/todos`);
      return response.data;
    } catch (error) {
      console.error('Error fetching todos:', error);
      throw error;
    }
  }

  async getUsers(): Promise<User[]> {
    try {
      const response = await axios.get<User[]>(`${API_BASE_URL}/users`);
      return response.data;
    } catch (error) {
      console.error('Error fetching users:', error);
      return [];
    }
  }

  async getUserPreferences(): Promise<UserPreferences> {
    try {
      const response = await axios.get<UserPreferences>(`${API_BASE_URL}/user-preferences`);
      return response.data;
    } catch (error) {
      console.error('Error fetching user preferences:', error);
      return {
        pet_care: false,
        laundry: false,
        cooking: false,
        organization: false,
        plant_care: false,
        house_work: false,
        yard_work: false,
        family_care: false
      };
    }
  }

  async updateUserPreferences(preferences: UserPreferences): Promise<void> {
    try {
      await axios.post(`${API_BASE_URL}/user-preferences`, preferences);
    } catch (error) {
      console.error('Error updating user preferences:', error);
      throw error;
    }
  }
}

export const todoService = new TodoService();
