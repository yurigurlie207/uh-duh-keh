// Common types for the React frontend

export interface Todo {
  id: string;
  title: string;
  completed: boolean;
  priority: string;
  assigned_to?: string;
  created_at?: string;
  updated_at?: string;
  ai_priority?: number;
  ai_reason?: string;
  Completed?: 'completed' | 'deleted' | null;
}

export interface UserPreferences {
  pet_care: boolean;
  laundry: boolean;
  cooking: boolean;
  organization: boolean;
  plant_care: boolean;
  house_work: boolean;
  yard_work: boolean;
  family_care: boolean;
}

export interface PrioritizedTodo extends Todo {
  aiPriority: number;
  aiReason: string;
}

export interface User {
  username: string;
}

export interface AuthResponse {
  token: string;
  username: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
}

export interface AIInsightsResponse {
  insights: string;
}
