import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserPreferences } from '../types';
import { authService } from '../services/authService';
import { todoService } from '../services/todoService';

const Profile: React.FC = () => {
  const [username, setUsername] = useState('');
  const [preferences, setPreferences] = useState<UserPreferences>({
    pet_care: false,
    laundry: false,
    cooking: false,
    organization: false,
    plant_care: false,
    house_work: false,
    yard_work: false,
    family_care: false
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!authService.isLoggedIn()) {
      navigate('/login');
      return;
    }

    const currentUsername = authService.getUsername();
    setUsername(currentUsername || '');
    loadUserPreferences();
  }, [navigate]);

  const loadUserPreferences = async () => {
    setLoading(true);
    try {
      const userPrefs = await todoService.getUserPreferences();
      setPreferences(userPrefs);
    } catch (error) {
      console.error('Error loading user preferences:', error);
      setError('Failed to load preferences');
    } finally {
      setLoading(false);
    }
  };

  const handlePreferenceChange = (key: keyof UserPreferences) => {
    setPreferences(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const savePreferences = async () => {
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      await todoService.updateUserPreferences(preferences);
      setSuccess('Preferences saved successfully!');
      setIsEditing(false);
      setTimeout(() => {
        setSuccess('');
      }, 3000);
    } catch (error) {
      console.error('Error saving preferences:', error);
      setError('Failed to save preferences');
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    authService.logout();
    navigate('/login');
  };

  if (loading && !isEditing) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <h1 className="text-3xl font-bold text-gray-900">Profile</h1>
              <span className="ml-4 text-sm text-gray-500">Welcome, {username}!</span>
            </div>
            <div className="flex space-x-4">
              <button
                onClick={() => navigate('/todos')}
                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
              >
                Todos
              </button>
              <button
                onClick={logout}
                className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          {/* User Info */}
          <div className="bg-white overflow-hidden shadow rounded-lg mb-6">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                User Information
              </h3>
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Username
                  </label>
                  <div className="mt-1 text-sm text-gray-900">{username}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Preferences */}
          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg leading-6 font-medium text-gray-900">
                  Task Preferences
                </h3>
                {!isEditing ? (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded"
                  >
                    Edit Preferences
                  </button>
                ) : (
                  <div className="space-x-2">
                    <button
                      onClick={savePreferences}
                      disabled={loading}
                      className="bg-green-600 hover:bg-green-700 disabled:bg-green-400 text-white font-bold py-2 px-4 rounded"
                    >
                      {loading ? 'Saving...' : 'Save'}
                    </button>
                    <button
                      onClick={() => {
                        setIsEditing(false);
                        loadUserPreferences();
                        setError('');
                        setSuccess('');
                      }}
                      className="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>

              {error && (
                <div className="mb-4 bg-red-50 border border-red-200 rounded-md p-4">
                  <div className="text-red-800">{error}</div>
                </div>
              )}

              {success && (
                <div className="mb-4 bg-green-50 border border-green-200 rounded-md p-4">
                  <div className="text-green-800">{success}</div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(preferences).map(([key, value]) => (
                  <div key={key} className="flex items-center">
                    <input
                      id={key}
                      type="checkbox"
                      checked={value}
                      onChange={() => handlePreferenceChange(key as keyof UserPreferences)}
                      disabled={!isEditing}
                      className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded disabled:opacity-50"
                    />
                    <label htmlFor={key} className="ml-3 text-sm font-medium text-gray-700 capitalize">
                      {key.replace('_', ' ')}
                    </label>
                  </div>
                ))}
              </div>

              <div className="mt-6 text-sm text-gray-500">
                <p>
                  These preferences help our AI assistant prioritize your tasks based on what you enjoy doing most.
                  Select the categories you prefer to work on, and the AI will prioritize those tasks higher.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Profile;
