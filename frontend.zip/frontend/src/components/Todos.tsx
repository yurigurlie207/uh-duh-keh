import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Todo } from '../types';
import { authService } from '../services/authService';
import { todoService } from '../services/todoService';
import { useSocket } from '../hooks/useSocket';

const Todos: React.FC = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [newTodoText, setNewTodoText] = useState('');
  // Assigned to defaults to "mom" for all new todos; no dropdowns needed
  const [username, setUsername] = useState('');
  // Countdown timer states
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [targetTime, setTargetTime] = useState<Date | null>(null);
  const [remaining, setRemaining] = useState<string>('');
  const lastAnnouncedBucketRef = useRef<number | null>(null);
  const [showDuck, setShowDuck] = useState<boolean>(false);
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [confirmDeletion, setConfirmDeletion] = useState<boolean>(false);
  const [selectedForDeletion, setSelectedForDeletion] = useState<Set<string>>(new Set());

  // Friendly speech helper
  const speakFriendly = useCallback((text: string) => {
    try {
      if (!('speechSynthesis' in window)) {
        console.log(text);
        return;
      }
      const synth = window.speechSynthesis;
      let voices = synth.getVoices();
      // Some browsers load voices asynchronously
      if (!voices || voices.length === 0) {
        synth.onvoiceschanged = () => {
          voices = synth.getVoices();
        };
      }
      const preferredNames = [
        // Prefer female voices first, especially British/UK
        'Google UK English Female', 'Serena', 'Martha', 'Moira', 'Tessa', // British female voices
        'Samantha', 'Victoria', 'Fiona', 'Karen', 'Allison', 'Ava', // US female voices
        'Google US English Female', 'Microsoft Zira Desktop', 'Microsoft Hazel Desktop', // Windows female voices
        'Alex', 'Samantha', 'Victoria', // macOS female voices
        // Male voices as fallback
        'Google UK English Male', 'Daniel', 'Google US English'
      ];
      const pick = () => {
        for (const name of preferredNames) {
          const v = voices.find(vo => vo.name.includes(name));
          if (v) return v;
        }
        // fallback: any en-GB, then any en-*, then first voice
        return (
          voices.find(v => (v.lang || '').toLowerCase().startsWith('en-gb')) ||
          voices.find(v => (v.lang || '').toLowerCase().startsWith('en')) ||
          voices[0]
        );
      };
      const utter = new SpeechSynthesisUtterance(text);
      const voice = pick();
      if (voice) utter.voice = voice;
      // Encourage British pronunciation and slower, warmer delivery
      utter.lang = (voice && voice.lang) ? voice.lang : 'en-GB';
      if (!utter.lang.toLowerCase().startsWith('en-gb')) {
        utter.lang = 'en-GB';
      }
      utter.rate = 0.82; // slower for clarity
      utter.pitch = 1.0; // natural, less robotic
      utter.volume = 1; // full volume
      synth.speak(utter);
    } catch (e) {
      console.log(text);
    }
  }, []);
  const navigate = useNavigate();
  const { emit, on, off } = useSocket();
  const hasLoadedData = useRef(false);


  const loadInitialData = useCallback(async () => {
    try {
      const todosData = await todoService.getTodos();
      setTodos(todosData);
    } catch (error) {
      console.error('Error loading initial data:', error);
    }
  }, []);

  // Removed user preferences (unused)

  const handleTodoCreated = useCallback((todo: Todo) => {
    setTodos(prev => [...prev, todo]);
  }, []);

  const handleTodoUpdated = useCallback((updatedTodo: Todo) => {
    setTodos(prev => prev.map(todo => 
      todo.id === updatedTodo.id ? updatedTodo : todo
    ));
  }, []);

  // Load initial data once when component mounts
  useEffect(() => {
    if (!authService.isLoggedIn()) {
      navigate('/login');
      return;
    }

    if (hasLoadedData.current) {
      return; // Already loaded data, don't load again
    }

    const currentUsername = authService.getUsername();
    setUsername(currentUsername || '');

    loadInitialData();
    hasLoadedData.current = true;
  }, [loadInitialData, navigate]);

    // Set up WebSocket listeners
  useEffect(() => {
    if (!authService.isLoggedIn()) {
      return;
    }

    on('todo:created', handleTodoCreated);
    on('todo:updated', handleTodoUpdated);
    on('todo:toggled', handleTodoUpdated);

    return () => {
      off('todo:created', handleTodoCreated);
      off('todo:updated', handleTodoUpdated);
      off('todo:toggled', handleTodoUpdated);
    };
  }, [on, off, handleTodoCreated, handleTodoUpdated]);

  // Countdown logic
  useEffect(() => {
    if (!targetTime) return;

    const interval = setInterval(() => {
      const now = new Date();
      const diff = targetTime.getTime() - now.getTime();

      // If we've passed the target, show duck and stop the timer (do not restart)
      if (diff <= 0) {
        speakFriendly('A Ducky!');
        setShowDuck(true);
        setTargetTime(null);
        clearInterval(interval);
        return;
      }

      const totalSeconds = Math.floor(diff / 1000);
      const hours = Math.floor(totalSeconds / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;
      const pad = (n: number) => n.toString().padStart(2, '0');
      setRemaining(`${pad(hours)}:${pad(minutes)}:${pad(seconds)}`);

      // Announce every 10 minutes on the minute
      const remainingMinutes = Math.ceil(totalSeconds / 60);
      const bucket = Math.floor(remainingMinutes / 10) * 10; // 50, 40, ...
      if (
        totalSeconds > 0 &&
        totalSeconds % 600 === 0 && // exact 10-minute boundary
        bucket !== lastAnnouncedBucketRef.current
      ) {
        const hoursLeft = Math.floor(remainingMinutes / 60);
        const minutesLeft = remainingMinutes % 60;
        const parts: string[] = [];
        if (hoursLeft > 0) parts.push(`${hoursLeft} ${hoursLeft === 1 ? 'hour' : 'hours'}`);
        if (minutesLeft > 0) parts.push(`${minutesLeft} ${minutesLeft === 1 ? 'minute' : 'minutes'}`);
        const phrase = parts.length ? `${parts.join(' and ')}` : 'less than a minute';
        const message = `There ${hoursLeft + minutesLeft === 1 ? 'is' : 'are'} ${phrase} remaining until you need to head out the door.`;
        speakFriendly(message);
        lastAnnouncedBucketRef.current = bucket;
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [targetTime, speakFriendly]);

  const setCountdown = () => {
    if (!selectedTime) return;
    const [hh, mm] = selectedTime.split(':').map(Number);
    const now = new Date();
    const target = new Date(now);
    target.setHours(hh, mm, 0, 0);
    if (target.getTime() <= now.getTime()) {
      // If selected time has already passed today, set for tomorrow
      target.setDate(target.getDate() + 1);
    }
    setShowDuck(false);
    setTargetTime(target);

    // Announce immediately when timer is set
    try {
      const diffMs = target.getTime() - now.getTime();
      const totalMinutes = Math.ceil(diffMs / 60000);
      const hoursLeft = Math.floor(totalMinutes / 60);
      const minutesLeft = totalMinutes % 60;
      const parts: string[] = [];
      if (hoursLeft > 0) parts.push(`${hoursLeft} ${hoursLeft === 1 ? 'hour' : 'hours'}`);
      if (minutesLeft > 0) parts.push(`${minutesLeft} ${minutesLeft === 1 ? 'minute' : 'minutes'}`);
      const phrase = parts.length ? `${parts.join(' and ')}` : 'less than a minute';
      const message = `There ${hoursLeft + minutesLeft === 1 ? 'is' : 'are'} ${phrase} remaining until you need to head out the door.`;
      speakFriendly(message);
      // Reset bucket so the next 10-min boundary will announce again as expected
      lastAnnouncedBucketRef.current = Math.floor(totalMinutes / 10) * 10;
    } catch (e) {
      // noop
    }
  };

  const addTodo = () => {
    if (!newTodoText.trim()) return;

    const todoData = {
      title: newTodoText.trim(),
      assigned_to: 'mom',
      priority: '999'
    };

    console.log('📤 Sending todo:create with data:', todoData);
    emit('todo:create', todoData);

    setNewTodoText('');
  };

  const toggleTodo = (todo: Todo) => {
    emit('todo:toggle', { id: todo.id, completed: !todo.completed });
  };

  const deleteTodo = (todo: Todo) => {
    emit('todo:delete', { id: todo.id });
    // Optimistically remove from UI while keeping row in DB (soft-delete on backend)
    setTodos(prev => prev.filter(t => t.id !== todo.id));
  };

  const completeTodo = (todo: Todo) => {
    // Mark as completed on server
    emit('todo:toggle', { id: todo.id, completed: true });
    // Optimistically remove from UI while keeping row in DB
    setTodos(prev => prev.filter(t => t.id !== todo.id));
  };

  const reloadTodos = async () => {
    try {
      const todosData = await todoService.getTodos();
      setTodos(todosData);
      
      // Also start the timer if a time is selected
      console.log('Restart the day clicked, selectedTime:', selectedTime);
      if (selectedTime) {
        console.log('Starting countdown with time:', selectedTime);
        setCountdown();
      } else {
        console.log('No time selected, skipping countdown');
      }
    } catch (e) {
      console.error('Failed to reload todos:', e);
    }
  };

  const toggleSelectionForDeletion = (todoId: string) => {
    setSelectedForDeletion(prev => {
      const newSet = new Set(prev);
      if (newSet.has(todoId)) {
        newSet.delete(todoId);
      } else {
        newSet.add(todoId);
      }
      return newSet;
    });
  };

  const hardDeleteSelected = () => {
    selectedForDeletion.forEach(todoId => {
      emit('todo:hard_delete', { id: todoId });
    });
    setTodos(prev => prev.filter(t => !selectedForDeletion.has(t.id)));
    setSelectedForDeletion(new Set());
  };



  const logout = () => {
    authService.logout();
    navigate('/login');
  };

  const sortedTodos = [...todos].sort((a, b) => {
    const aPriority = parseInt(a.priority) || 999;
    const bPriority = parseInt(b.priority) || 999;
    return aPriority - bPriority;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <h1 className="text-3xl font-bold text-gray-900">a Ducky</h1>
              <img
                src="https://twemoji.maxcdn.com/v/latest/svg/1f425.svg"
                alt="Yellow duck"
                className="w-8 h-8 ml-3"
              />
            </div>
            <div className="flex space-x-4 items-center">
              <span className="text-sm text-gray-500 mr-2">Welcome, {username}!</span>
              <button
                onClick={() => navigate('/profile')}
                className="bg-orange-500 hover:bg-orange-600 text-white font-semibold py-2 px-4 rounded"
              >
                Profile
              </button>
              <button
                onClick={logout}
                className="bg-orange-500 hover:bg-orange-600 text-white font-semibold py-2 px-4 rounded"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          {/* Add Todo */}
          <div className="bg-white overflow-hidden shadow rounded-lg mb-6">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                Add to morning routine
              </h3>
              <div className="flex space-x-4">
                <input
                  type="text"
                  value={newTodoText}
                  onChange={(e) => setNewTodoText(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addTodo()}
                  placeholder="Enter todo..."
                  className="w-full max-w-[500px] border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
                <button
                  onClick={addTodo}
                  className="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-2 px-4 rounded"
                >
                  Add
                </button>
                <button
                  onClick={() => setIsEditMode(!isEditMode)}
                  className={`px-4 py-2 rounded font-semibold ${
                    isEditMode
                      ? 'bg-red-100 text-red-800 border border-red-300'
                      : 'bg-yellow-500 hover:bg-yellow-600 text-white'
                  }`}
                >
                  {isEditMode ? 'Exit Edit' : 'Edit'}
                </button>
          </div>

              {/* Countdown setter */}
              <div className="mt-5 flex items-center space-x-3">
                <label className="text-sm text-gray-700">Set Time Out the Door:</label>
                <input
                  type="time"
                  value={selectedTime}
                  onChange={(e) => setSelectedTime(e.target.value)}
                  className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
                <button
                  onClick={() => { /* Set button no longer starts countdown */ }}
                  className="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-2 px-4 rounded"
                >
                  Set
                </button>
              </div>
              <div className="mt-6 flex space-x-3">
                <button
                  onClick={reloadTodos}
                  className="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold px-3 py-2 rounded-md text-sm"
                >
                  Restart the day
                </button>
                <button
                  onClick={() => {
                    setTargetTime(null);
                    setShowDuck(false);
                    setRemaining('');
                  }}
                  className="bg-red-400 hover:bg-red-500 text-white font-semibold px-3 py-2 rounded-md text-sm"
                >
                  Stop
                </button>
              </div>
            </div>
          </div>

          {/* Todos Grid */}
          <div className="bg-white shadow overflow-hidden sm:rounded-xl p-5">
            {(targetTime || showDuck) && (
              <div className="text-center mb-4 text-sm text-gray-700">
                {showDuck ? (
                  <div className="inline-flex items-center space-x-2">
                    <span className="font-semibold text-gray-800">Time is up!</span>
                    <img
                      src="https://twemoji.maxcdn.com/v/latest/svg/1f425.svg"
                      alt="Time is up!"
                      title="Time is up!"
                      className="w-5 h-5"
                    />
                  </div>
                ) : (
                  <span className="text-lg">
                    Time remaining: <span className={`font-bold text-xl ${(() => {
                      // Parse remaining time to get minutes
                      const parts = remaining.split(':');
                      const hours = parseInt(parts[0]) || 0;
                      const minutes = parseInt(parts[1]) || 0;
                      const totalMinutes = hours * 60 + minutes;
                      return totalMinutes > 5 ? 'text-green-600' : 'text-red-600';
                    })()}`}>{remaining}</span>
                  </span>
                )}
              </div>
            )}
            <div className="text-center mb-6">
              <h2 className="text-2xl font-medium italic text-gray-800">You've got this, Family!</h2>
            </div>
            {todos.length === 0 && (
              <div className="text-center my-6">
                <img
                  src="https://twemoji.maxcdn.com/v/latest/svg/1f425.svg"
                  alt="All tasks cleared!"
                  title="All tasks cleared!"
                  className="w-24 h-24 mx-auto"
                />
              </div>
            )}
            <div className="flex justify-start items-center mb-4 space-x-3">
              {isEditMode && selectedForDeletion.size > 0 && (
                <button
                  onClick={hardDeleteSelected}
                  className="bg-red-500 hover:bg-red-600 text-white font-semibold px-3 py-1 rounded-md text-sm"
                >
                  Delete Selected ({selectedForDeletion.size})
                </button>
              )}
            </div>
            <div className="flex flex-wrap gap-4 justify-center">
              {sortedTodos.map((todo) => (
                <div key={todo.id} className="relative">
                  {isEditMode && (
                    <button
                      onClick={() => toggleSelectionForDeletion(todo.id)}
                      className="absolute inset-0 z-20 bg-transparent font-extrabold text-4xl rounded-2xl flex items-center justify-center drop-shadow hover:scale-105 transition-transform"
                      aria-label="Select for deletion"
                    >
                      {selectedForDeletion.has(todo.id) && (
                        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                          <line x1="10" y1="10" x2="90" y2="90" stroke="#ef4444" strokeWidth="3" strokeLinecap="round" />
                          <line x1="90" y1="10" x2="10" y2="90" stroke="#ef4444" strokeWidth="3" strokeLinecap="round" />
                        </svg>
                      )}
                    </button>
                  )}
                  <button
                    onClick={() => { speakFriendly(`${todo.title} needs to be done.`); }}
                    title={todo.title}
                    className={`
                      w-16 h-16 sm:w-20 sm:h-20
                      rounded-2xl
                      flex items-center justify-center
                      text-[11px] sm:text-sm text-center leading-tight p-2 font-medium
                      transition-all select-none
                      border
                      focus:outline-none focus:ring-2 focus:ring-indigo-300
                      ${isEditMode ? 'bg-gray-100 text-gray-500 border-gray-200' : 'bg-yellow-50 text-gray-900 border-yellow-200 hover:bg-yellow-100 hover:border-yellow-300 shadow-md hover:shadow-lg'}
                    `}
                  >
                    <span className={`line-clamp-3`}>
                      {todo.title}
                    </span>
                  </button>
                  {!isEditMode && (
                    <>
                      <button
                        onClick={() => completeTodo(todo)}
                        aria-label="Complete todo"
                        className="absolute bottom-1 right-1 z-10 bg-white border border-green-200 rounded-full w-7 h-7 flex items-center justify-center text-green-600 hover:text-green-700 shadow transform translate-x-[12px] translate-y-[11px]"
                      >
                        ✓
                      </button>
                      <button
                        onClick={() => deleteTodo(todo)}
                        aria-label="Delete todo"
                        className="absolute -top-1 -left-1 bg-white border border-gray-200 rounded-full w-6 h-6 flex items-center justify-center text-red-500 hover:text-red-600 shadow transform -translate-x-[3px] -translate-y-[3px]"
                      >
                        ×
                      </button>
                    </>
                  )}
                  </div>
              ))}
            </div>
            {todos.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No todos yet. Add one above to get started!
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Todos;
