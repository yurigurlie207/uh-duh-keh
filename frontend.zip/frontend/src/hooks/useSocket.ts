/*this version is not using socket - it is using long-polling*/

import { useCallback, useEffect, useRef, useState } from 'react';
import io from 'socket.io-client';
import type { Socket } from 'socket.io-client/build/esm/socket';
import type { DefaultEventsMap } from '@socket.io/component-emitter';
import { authService } from '../services/authService';

type IOSocket = Socket<DefaultEventsMap, DefaultEventsMap>;

const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || 'http://localhost:3002';

export const useSocket = () => {
  const [socket, setSocket] = useState<IOSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const socketRef = useRef<IOSocket | null>(null);

  useEffect(() => {
    const token = authService.getToken();

    console.log('Token exists:', !!token);
    console.log('Token preview:', token?.slice(0, 20) + '...');
    
    if (!token) {
      console.log('No auth token, not connecting to socket');
      return;
    }

    console.log('Connecting to socket with token...');
    
// useSocket.ts (WebSocket-only)
const newSocket = io(SOCKET_URL, {
  auth: { token },        // correct way to send token
  transports: ['websocket']
});

  socketRef.current = newSocket as unknown as IOSocket;

    newSocket.on('connect', () => {
      console.log('✅ Connected to WebSocket server');
      setIsConnected(true);
    });

    newSocket.on('disconnect', (reason: string) => {
      console.log('❌ Disconnected from WebSocket server:', reason);
      setIsConnected(false);
    });

    newSocket.on('connect_error', (error: unknown) => {
      console.error('Socket connection error:', error);
      setIsConnected(false);
    });

    newSocket.on('auth_error', (error: unknown) => {
      console.error('❌ Authentication error:', error);
      setIsConnected(false);
      // Optionally redirect to login or show auth error
    });

    newSocket.on('error', (error: unknown) => {
      console.error('Socket error:', error);
    });

  setSocket(newSocket as unknown as IOSocket);

    return () => {
      console.log('Cleaning up socket connection');
      newSocket.close();
      socketRef.current = null;
      setSocket(null);
      setIsConnected(false);
    };
  }, []);

  const emit = useCallback((event: string, data?: any) => {
    if (socketRef.current) {
      console.log('📤 Emitting event:', event, data);
      socketRef.current.emit(event, data);
    } else {
      console.warn('Socket not connected, cannot emit event:', event);
    }
  }, []);

  const on = useCallback((event: string, callback: (data: any) => void) => {
    if (socketRef.current) {
      socketRef.current.on(event, callback);
    }
  }, []);

  const off = useCallback((event: string, callback?: (data: any) => void) => {
    if (socketRef.current) {
      socketRef.current.off(event, callback);
    }
  }, []);

  return {
    socket,
    isConnected,
    emit,
    on,
    off
  };
};
